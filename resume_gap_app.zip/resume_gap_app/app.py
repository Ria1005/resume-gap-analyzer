"""Resume-to-Job Gap Analyzer - web page (M4).  Run:  streamlit run app.py"""
import tempfile
from pathlib import Path
import streamlit as st
from gap_engine import analyse_text, report, ADVICE, CATEGORY

st.set_page_config(page_title="Resume-to-Job Gap Analyzer", page_icon="📄", layout="wide")
st.title("📄 Resume-to-Job Gap Analyzer")
st.write("Upload your resume, paste a job description, and see how well they match and what is missing.")

left, right = st.columns(2)
with left:
    st.subheader("1. Your resume")
    up = st.file_uploader("PDF, Word (.docx) or text file", type=["pdf", "docx", "txt"])
with right:
    st.subheader("2. Job description")
    jd = st.text_area("Paste the job description here", height=220,
                      placeholder="Required skills: ...\nPreferred skills: ...")
    st.caption("Tip: if the text has a 'Preferred' or 'Nice to have' part, those skills count less.")

if st.button("Analyse", type="primary"):
    if up is None or not jd.strip():
        st.warning("Please upload a resume AND paste a job description.")
    else:
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / up.name
            p.write_bytes(up.getvalue())
            try:
                r = analyse_text(p, jd)
            except Exception as e:
                st.error(f"Could not read the resume: {e}"); st.stop()
        if not r["req"] and not r["pref"]:
            st.error("No known skills were found in the job description. Paste a longer description that lists skills.")
            st.stop()

        st.divider()
        c1, c2, c3 = st.columns(3)
        c1.metric("Match score", f"{r['score']}%")
        c2.metric("Verdict", f"{r['verdict']} match")
        c3.metric("Required skills matched", f"{len(r['matched_req'])} / {len(r['req'])}")
        st.progress(min(int(r["score"]), 100))

        a, b, c = st.columns(3)
        with a:
            st.success("✅ Skills you have")
            for s in r["matched_req"] + r["matched_pref"]: st.write("•", s)
            if not (r["matched_req"] + r["matched_pref"]): st.write("None")
        with b:
            st.warning("🟡 Partly matching")
            for s, o in r["partial_req"] + r["partial_pref"]: st.write(f"• {s} (you have {o})")
            if not (r["partial_req"] + r["partial_pref"]): st.write("None")
        with c:
            st.error("❌ Missing skills")
            for s in r["missing_req"]: st.write(f"• {s} (required)")
            for s in r["missing_pref"]: st.write(f"• {s} (preferred)")
            if not (r["missing_req"] + r["missing_pref"]): st.write("None")

        gaps = r["missing_req"] + r["missing_pref"] + [s for s, _ in r["partial_req"]]
        if gaps:
            st.subheader("What to do")
            for s in r["missing_req"]:   st.write(f"**{s}** (required): {ADVICE[CATEGORY[s]]}")
            for s, o in r["partial_req"]: st.write(f"**{s}** (required): you know {o}, so mention it or learn {s}; they are similar.")
            for s in r["missing_pref"]:  st.write(f"**{s}** (preferred): {ADVICE[CATEGORY[s]]}")

        with st.expander("Skills found in your resume"):
            st.write(", ".join(r["resume_skills"]) or "None found")
            st.caption("Sections detected: " + (", ".join(r["sections"]) or "none"))
        st.download_button("Download report (.txt)", report(r), file_name="gap_report.txt")
