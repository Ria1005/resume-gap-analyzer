@echo off
echo Installing needed libraries (first time only)...
pip install streamlit pdfplumber python-docx pandas
echo Starting the app. A browser page will open.
python -m streamlit run app.py
pause
